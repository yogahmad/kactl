#include<bits/stdc++.h>
using namespace std;

int main() {
	assert(0);
	int x = 1;
	assert(x == 0);
}
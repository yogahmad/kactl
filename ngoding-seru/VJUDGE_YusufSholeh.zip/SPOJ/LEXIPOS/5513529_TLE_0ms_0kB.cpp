#include<bits/stdc++.h>
using namespace std;

int main() {
   int c = 0;
   while(1) {
      c++;
   }
}
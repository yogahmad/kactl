#include<bits/stdc++.h>
#define MAX 500
using namespace std;
int tc;
char p[MAX][MAX];
int main() {
	scanf("%d",&tc);
	while(tc--) {
		scanf("%d",&n);
		for(int i = 0; i < n; i++) gets(p[i]);
	}
}